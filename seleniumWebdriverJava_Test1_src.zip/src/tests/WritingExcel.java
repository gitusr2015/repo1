package tests;
import java.io.File;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.Label;
import jxl.write.WriteException;


public class WritingExcel {
	
 
 public static void main(String[] args) throws Exception {
	 
  try{
	  File file = new File("./DataPool/output.xls");
	  
	  WritableWorkbook wb = Workbook.createWorkbook(file);
	  WritableSheet sht = wb.createSheet("data", 0);
	  sht.addCell(new Label(0, 0,  "Column1_Header"));
	  sht.addCell(new Label(1, 0, "Column2_Header"));
	  sht.addCell(new Label(2, 0, "Column3_Header"));
	  for (int r = 1; r <11; r++) {
		  int c = 0;
		//  for (int c = 0; c<10; c++) {
			  Label ll = new Label(c, r, "Result");
			  sht.addCell(ll);
			  sht.addCell(new Label(c+1, r,  "Pass"));
			  sht.addCell(new Label(c+2, r, "Fail"));
			  
			 
		// }
	  }
	  wb.write();
	  wb.close();
	  System.out.println("Workbook is created");
 } 	catch(Exception e)
	{
		e.printStackTrace();
		
	}
	System.out.println("NO MATCH FOUND IN GIVEN FILE: PROBLEM IS COMING FROM DATA FILE");
 }
}
