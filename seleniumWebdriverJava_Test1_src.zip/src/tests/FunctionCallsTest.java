////////////////////////////////////////////////////
// Some UI functionality (SignIn, SignOut, DeleteCart, SearchAdd, ..etc.) written as functions in package Functions
// Here is to run the tests by calling those functions
// By:  Julianne X.
///////////////////////////////////////////////////

package tests;

import Functions.My_Functions;
import java.lang.Double;
import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.Properties;
import java.io.FileInputStream;


public class FunctionCallsTest extends My_Functions{
//  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
  
 // public Properties prop;

  @Before
  public void setUp() throws Exception {
//	System.setProperty("webdriver.gecko.driver", "C:\\Selenium\\workspace\\HotelApp_TestAutomation\\Lib");
//	prop  = new Properties();
//	prop.load(new FileInputStream("./SharedUIMap/SharedUIMap.properties"));
	/*  driver = getDriver("chrome");  // user defined Functions.My_Functions - input "chrome" or "firefox", else default to microsoft edge on windows 10
	  baseUrl = "https://www.amazon.ca";
	  driver.manage().deleteAllCookies();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  */
  }


  @Test
  public void testFunctions() throws Exception {
	  
	  driver = getDriver("chrome");  // user defined Functions.My_Functions - input "chrome" or "firefox", else default to microsoft edge on windows 10
	  baseUrl = "https://www.amazon.ca";
	  driver.manage().deleteAllCookies();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
      driver.get(baseUrl + "/");
      
      SignIn("janedoe@gmail.com" , "pwd12345"); //
      DeleteCart();

  	  double unitPrice1 = SearchAdd("Fruit of the Loom Women's Ladies Core Soft Spun Assorted  Ankle Socks");
	  double unitPrice2 =  SearchAdd("ITALY MORN Mens Chino Jogger Pants Casual Khaki Slim Fit Jogging Pant");
	  double unitPrice3 = SearchAdd("InterDesign Twillo Mail, Letter Holder, Key Rack Organizer for Entryway, Kitchen - Wall Mount, Matte Black");
	  double sum = roundTwoDecimals(unitPrice1+unitPrice2+unitPrice3);
	  double cartSub = CartSubtotal() ;
	  if (cartSub == sum)
		  System.out.println("Sum of item unit price equals to cart subtotal.");
	  System.out.println( "Items added: " +   String.valueOf(CartCount())  + ";  Cart Subtotal: " + String.valueOf(CartSubtotal()) +", Sum(selected item unit price): " + String.valueOf(cartSub ));
	  
      SignOut();    //currently not working with Edge
	  System.out.println("Signed out.");
	  //Thread.sleep(1000);
	  driver.quit();
  }


  @After
  public void tearDown() throws Exception {
   // driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
