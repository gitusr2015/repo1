package Functions;


import Functions.My_Functions;
import java.util.Properties;
import java.io.FileInputStream;


public class My_LoadConfigFunctions extends My_Functions{
  //  public static Properties prop;
	private String sSharedUIMapPath;
	private String sAppURL;
	
	public String MA_getAppURL(){
		return sAppURL;
	}
	
	
	public void MA_Config () throws Exception {
		prop  = new Properties();
//		prop.load(new FileInputStream(sConfigPath));
	    prop.load(new FileInputStream("./Configuration/MA_Configuration.properties"));
		sAppURL = prop.getProperty("AppUrl");
	  //prop.load(new FileInputStream("./SharedUIMap/SharedUIMap.properties"));
		sSharedUIMapPath = prop.getProperty("SharedUIMap");
		prop.load(new FileInputStream(sSharedUIMapPath));
	}

}
