package tests;

import java.io.File;
import java.io.IOException;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class ReadingExcel {

 public static void main(String[] args) throws BiffException, IOException {
  File file = new File("./DataPool/Input.xls");
  Workbook wb = Workbook.getWorkbook(file);
  
  Sheet sheet = wb.getSheet(0);
  
  int noOfRows = sheet.getRows();
  int noOfColumns = sheet.getColumns();
  
  System.out.println("No of Rows: " + noOfRows);
  System.out.println("No of Columns: " + noOfColumns);
  
  System.out.println("Cell02 1st Column and 3rd Row: " 
  + sheet.getCell(0, 2).getContents());
  String data = "";
  for (int i = 0; i < noOfRows; i++) {
   for (int j = 0; j < noOfColumns; j++) {
    data = sheet.getCell(j, i).getContents();
    System.out.print(data + "\t");
   }
   System.out.println();
  }
  wb.close();
 }
}